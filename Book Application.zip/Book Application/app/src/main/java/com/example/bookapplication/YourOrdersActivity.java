package com.example.bookapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class YourOrdersActivity extends AppCompatActivity {

    private ListView ordersListView;
    private Button proceedButton;

    // Dummy list of orders
    private ArrayList<String> ordersList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.yourorders);

        ordersListView = findViewById(R.id.orders_list_view);
        proceedButton = findViewById(R.id.proceed_button);

        // Add some dummy orders for demonstration
        ordersList.add("fiction_1");
        ordersList.add("Book 2");
        ordersList.add("Book 3");

        // Populate the ListView with orders
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, ordersList);
        ordersListView.setAdapter(adapter);

        // Handle click event of the "Proceed" button
        proceedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Send email to the user
                sendEmail();
            }
        });
    }

    // Method to send email to the user
    private void sendEmail() {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"user@example.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your Order Details");
        emailIntent.putExtra(Intent.EXTRA_TEXT, getOrderDetails());
        if (emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(emailIntent, "Send Email"));
        }
    }

    // Method to get order details
    private String getOrderDetails() {
        StringBuilder builder = new StringBuilder();
        builder.append("Your Orders:\n");
        for (String order : ordersList) {
            builder.append(order).append("\n");
        }
        return builder.toString();
    }
}
