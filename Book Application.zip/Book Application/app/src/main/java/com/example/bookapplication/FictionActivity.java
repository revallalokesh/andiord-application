package com.example.bookapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class FictionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.books);

        // Assuming the ID for the "Add to Cart" button for the first book is add_to_cart_button_fiction_1
        Button addToCartButton = findViewById(R.id.add_to_cart_button_1);

        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FictionActivity.this, YourOrdersActivity.class);
                startActivity(intent);
            }
        });
    }
}
