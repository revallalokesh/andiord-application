package com.example.bookapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ThrillerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thriller);

        // Add your code for Thriller category here
    }
}
