package com.example.bookapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class AdventureActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adventure);

        // Add your logic here
        // For example, you can initialize views and set up click listeners for buttons
    }
}
