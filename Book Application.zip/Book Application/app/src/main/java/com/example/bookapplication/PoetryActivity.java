package com.example.bookapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class PoetryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.poetry);

        // Add your code for Poetry category here
    }
}
