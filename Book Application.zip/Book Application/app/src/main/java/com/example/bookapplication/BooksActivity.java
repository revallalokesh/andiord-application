package com.example.bookapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

public class BooksActivity extends AppCompatActivity {

    // Declare constant IDs for category buttons
    private static final int FICTION_CATEGORY_ID = R.id.categoryFiction;
    private static final int DRAMA_CATEGORY_ID = R.id.drama_category;
    private static final int THRILLER_CATEGORY_ID = R.id.thriller_category;
    private static final int POETRY_CATEGORY_ID = R.id.poetry_category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        // Set click listeners for category buttons
        findViewById(FICTION_CATEGORY_ID).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToCategory(FICTION_CATEGORY_ID);
            }
        });

        findViewById(DRAMA_CATEGORY_ID).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToCategory(DRAMA_CATEGORY_ID);
            }
        });

        findViewById(THRILLER_CATEGORY_ID).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToCategory(THRILLER_CATEGORY_ID);
            }
        });

        findViewById(POETRY_CATEGORY_ID).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToCategory(POETRY_CATEGORY_ID);
            }
        });
    }

    // Method to navigate to the selected category activity
    private void navigateToCategory(int categoryId) {
        Intent intent;
        if (categoryId == FICTION_CATEGORY_ID) {
            intent = new Intent(BooksActivity.this, FictionActivity.class);
        } else if (categoryId == DRAMA_CATEGORY_ID) {
            intent = new Intent(BooksActivity.this, DramaActivity.class);
        } else if (categoryId == THRILLER_CATEGORY_ID) {
            intent = new Intent(BooksActivity.this, ThrillerActivity.class);
        } else if (categoryId == POETRY_CATEGORY_ID) {
            intent = new Intent(BooksActivity.this, PoetryActivity.class);
        } else {
            // Handle other cases if needed
            return;
        }
        startActivity(intent);
    }
}