package com.example.bookapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        // Find each category LinearLayout by ID
        LinearLayout categoryFiction = findViewById(R.id.categoryFiction);
        LinearLayout categoryDrama = findViewById(R.id.categoryDrama);
        LinearLayout categoryPoetry = findViewById(R.id.categoryPoetry);
        LinearLayout categoryThriller = findViewById(R.id.categoryThriller);
        LinearLayout categoryHorror = findViewById(R.id.categoryHorror);
        LinearLayout categoryRomance = findViewById(R.id.categoryRomance);
        LinearLayout categoryMystery = findViewById(R.id.categoryMystery);
        LinearLayout categoryAdventure = findViewById(R.id.categoryAdventure);
        LinearLayout categoryBiography = findViewById(R.id.categoryBiography);

        // Find other category LinearLayouts similarly

        // Set OnClickListener for each category
        categoryFiction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start FictionActivity when Fiction category is clicked
                startActivity(new Intent(CategoryActivity.this, FictionActivity.class));
            }
        });

        categoryDrama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start DramaActivity when Drama category is clicked
                startActivity(new Intent(CategoryActivity.this, DramaActivity.class));
            }
        });

        categoryPoetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, PoetryActivity.class));
            }
        });

        categoryThriller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, ThrillerActivity.class));
            }
        });

        categoryHorror.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, HorrorActivity.class));
            }
        });

        categoryRomance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, RomanceActivity.class));
            }
        });

        categoryMystery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, MysteryActivity.class));
            }
        });

        categoryAdventure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, AdventureActivity.class));
            }
        });

        categoryBiography.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PoetryActivity when Poetry category is clicked
                startActivity(new Intent(CategoryActivity.this, BiographyActivity.class));
            }
        });








        // Set OnClickListener for other categories similarly
    }
}
